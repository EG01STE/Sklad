﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Sklad
{
    public partial class Form2 : Form
    {
        private DataTable equipmentTable;
        private DataView dataView;

        public Form2()
        {
            InitializeComponent();
            ApplyButtonsRounded();

            // Проверка подключения к БД
            if (!DatabaseHelper.TestConnection(out string error))
            {
                MessageBox.Show($"Ошибка подключения к БД:\n{error}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
                return;
            }

            LoadEquipmentData();
            SetupDataGridView();
            dataGridView1.DataSource = dataView;   // ОБЯЗАТЕЛЬНО: присваиваем источник данных
            comboBox1.SelectedIndex = 0;
            UpdateStatus();
        }

        public void RefreshEquipmentData()
        {
            LoadEquipmentData();
            dataView = new DataView(equipmentTable);
            dataGridView1.DataSource = dataView;
            ApplyCurrentFiltersAndSort();
            UpdateStatus();
        }

        private void LoadEquipmentData()
        {
            equipmentTable = DatabaseHelper.ExecuteQuery("SELECT * FROM vwEquipment ORDER BY Категория");
            dataView = new DataView(equipmentTable);
        }

        private void ApplyCurrentFiltersAndSort()
        {
            string filter = dataView.RowFilter;
            string sort = dataView.Sort;
            dataView = new DataView(equipmentTable);
            dataView.RowFilter = filter;
            dataView.Sort = sort;
            dataGridView1.DataSource = dataView;
        }

        private void ApplyButtonsRounded()
        {
            MakeButtonRounded(button1);
            MakeButtonRounded(button2);
            MakeButtonRounded(button3);
            MakeButtonRounded(button4);
            MakeButtonRounded(button5);
            MakeButtonRounded(button6);
            MakeButtonRounded(button7);
            MakeButtonRounded(button8);
            MakeButtonRounded(button9);
        }

        private void MakeButtonRounded(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            int radius = 8;
            path.AddArc(0, 0, radius, radius, 180, 90);
            path.AddArc(btn.Width - radius, 0, radius, radius, 270, 90);
            path.AddArc(btn.Width - radius, btn.Height - radius, radius, radius, 0, 90);
            path.AddArc(0, btn.Height - radius, radius, radius, 90, 90);
            path.CloseFigure();
            btn.Region = new Region(path);
        }

        private void SetupDataGridView()
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.BorderStyle = BorderStyle.None;
            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.RowTemplate.Height = 35;
            dataGridView1.Font = new Font("Segoe UI", 10F);
            dataGridView1.GridColor = Color.FromArgb(230, 230, 230);
            dataGridView1.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;

            dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 248, 248);
            dataGridView1.RowsDefaultCellStyle.BackColor = Color.White;
            dataGridView1.RowsDefaultCellStyle.ForeColor = Color.FromArgb(44, 62, 80);
            dataGridView1.AlternatingRowsDefaultCellStyle.ForeColor = Color.FromArgb(44, 62, 80);
            dataGridView1.RowsDefaultCellStyle.SelectionBackColor = Color.FromArgb(52, 152, 219);
            dataGridView1.RowsDefaultCellStyle.SelectionForeColor = Color.White;

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(52, 73, 94);
            dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.ColumnHeadersHeight = 45;

            dataGridView1.RowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
            if (dataGridView1.Columns["Количество"] != null)
                dataGridView1.Columns["Количество"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            if (dataGridView1.Columns["Свободно"] != null)
                dataGridView1.Columns["Свободно"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            if (dataGridView1.Columns["Занято"] != null)
                dataGridView1.Columns["Занято"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            if (dataGridView1.Columns["Дата привоза"] != null)
            {
                dataGridView1.Columns["Дата привоза"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                dataGridView1.Columns["Дата привоза"].DefaultCellStyle.Format = "dd.MM.yyyy";
            }

            dataGridView1.CellFormatting += DataGridView1_CellFormatting;

            if (dataGridView1.Columns["ID"] != null)
                dataGridView1.Columns["ID"].Visible = false;
        }

        private void DataGridView1_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dataGridView1.Columns[e.ColumnIndex].Name == "Статус" && e.Value != null)
            {
                string status = e.Value.ToString();
                if (status == "На складе")
                {
                    e.CellStyle.BackColor = Color.FromArgb(223, 240, 216);
                    e.CellStyle.ForeColor = Color.FromArgb(60, 118, 61);
                    e.CellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
                }
                else if (status == "Распределено")
                {
                    e.CellStyle.BackColor = Color.FromArgb(252, 248, 227);
                    e.CellStyle.ForeColor = Color.FromArgb(138, 109, 59);
                    e.CellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
                }
                else if (status == "Выдано")
                {
                    e.CellStyle.BackColor = Color.FromArgb(242, 222, 222);
                    e.CellStyle.ForeColor = Color.FromArgb(169, 68, 66);
                    e.CellStyle.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
                }
                e.CellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            }
        }

        private void UpdateStatus()
        {
            toolStripStatusLabel1.Text = $"Записей: {dataView.Count}";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string filter = textBox1.Text.Trim();
            if (string.IsNullOrEmpty(filter))
                dataView.RowFilter = "";
            else
                dataView.RowFilter = $"Категория LIKE '%{filter}%' OR Название LIKE '%{filter}%' OR Модель LIKE '%{filter}%'";
            UpdateStatus();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sortColumn = comboBox1.SelectedItem.ToString();
            switch (sortColumn)
            {
                case "Категория": dataView.Sort = "Категория ASC"; break;
                case "Название": dataView.Sort = "Название ASC"; break;
                case "Модель": dataView.Sort = "Модель ASC"; break;
                case "Количество": dataView.Sort = "Количество ASC"; break;
                case "Дата привоза": dataView.Sort = "[Дата привоза] DESC"; break;
                case "Статус": dataView.Sort = "Статус ASC"; break;
                default: dataView.Sort = "Категория ASC"; break;
            }
        }

        private void button1_Click(object sender, EventArgs e) // На складе
        {
            dataView.RowFilter = "";
            textBox1_TextChanged(null, null);
            UpdateStatus();
            HighlightActiveButton(button1);
        }

        private void button2_Click(object sender, EventArgs e) // Привозы
        {
            DataTable dt = DatabaseHelper.ExecuteQuery("SELECT DISTINCT [Дата привоза] FROM vwEquipment ORDER BY [Дата привоза] DESC");
            if (dt.Rows.Count == 0)
            {
                MessageBox.Show("Нет данных о привозках.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            var dates = new System.Collections.Generic.List<DateTime>();
            foreach (DataRow row in dt.Rows)
                dates.Add(Convert.ToDateTime(row["Дата привоза"]));
            DateTime? selectedDate = ShowDeliveryDateDialog(dates);
            if (selectedDate.HasValue)
            {
                dataView.RowFilter = $"[Дата привоза] = #{selectedDate.Value:yyyy-MM-dd}#";
                textBox1.Text = "";
                UpdateStatus();
            }
            else
            {
                dataView.RowFilter = "";
                textBox1.Text = "";
                UpdateStatus();
            }
            HighlightActiveButton(button2);
        }

        private DateTime? ShowDeliveryDateDialog(System.Collections.Generic.List<DateTime> dates)
        {
            Form dialog = new Form();
            dialog.Text = "Выбор привозки";
            dialog.Width = 350;
            dialog.Height = 200;
            dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
            dialog.StartPosition = FormStartPosition.CenterParent;
            dialog.BackColor = Color.White;

            Label label = new Label() { Text = "Выберите дату привозки:", Left = 20, Top = 20, Width = 280, Font = new Font("Segoe UI", 10F) };
            ComboBox comboBox = new ComboBox() { Left = 20, Top = 50, Width = 250, DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 10F) };
            foreach (var date in dates) comboBox.Items.Add(date.ToString("dd.MM.yyyy"));
            if (comboBox.Items.Count > 0) comboBox.SelectedIndex = 0;

            Button okButton = new Button() { Text = "Показать", Left = 50, Width = 100, Top = 100, DialogResult = DialogResult.OK, BackColor = Color.FromArgb(52, 152, 219), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            Button allButton = new Button() { Text = "Все привозки", Left = 170, Width = 100, Top = 100, DialogResult = DialogResult.Cancel, BackColor = Color.FromArgb(149, 165, 166), ForeColor = Color.White, FlatStyle = FlatStyle.Flat };

            dialog.Controls.Add(label);
            dialog.Controls.Add(comboBox);
            dialog.Controls.Add(okButton);
            dialog.Controls.Add(allButton);
            dialog.AcceptButton = okButton;
            dialog.CancelButton = allButton;

            if (dialog.ShowDialog() == DialogResult.OK && comboBox.SelectedItem != null)
            {
                string selectedDateStr = comboBox.SelectedItem.ToString();
                DateTime parsed = DateTime.ParseExact(selectedDateStr, "dd.MM.yyyy", System.Globalization.CultureInfo.InvariantCulture);
                return parsed;
            }
            return null;
        }

        private void button3_Click(object sender, EventArgs e) // Выдача сотруднику
        {
            Form3 employeeForm = new Form3(this);
            employeeForm.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e) // Добавить
        {
            Form4 addForm = new Form4(this);
            addForm.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e) // Редактировать
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись для редактирования.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int id = (int)dataGridView1.SelectedRows[0].Cells["ID"].Value;
            Form4 editForm = new Form4(this, id);
            editForm.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e) // Удалить
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите запись для удаления.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int id = (int)dataGridView1.SelectedRows[0].Cells["ID"].Value;
            string name = dataGridView1.SelectedRows[0].Cells["Название"].Value.ToString();

            if (MessageBox.Show($"Удалить оборудование \"{name}\"?\nЭто действие необратимо.", "Подтверждение",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                try
                {
                    // Сначала удаляем связанные записи в Issues
                    DatabaseHelper.ExecuteNonQuery("DELETE FROM Issues WHERE EquipmentID = @id", new SqlParameter[] { new SqlParameter("@id", id) });
                    DatabaseHelper.ExecuteNonQuery("DELETE FROM Equipment WHERE EquipmentID = @id", new SqlParameter[] { new SqlParameter("@id", id) });
                    RefreshEquipmentData();
                    MessageBox.Show("Оборудование удалено.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка при удалении: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button7_Click(object sender, EventArgs e) // Сброс фильтров
        {
            textBox1.Text = "";
            comboBox1.SelectedIndex = 0;
            dataView.RowFilter = "";
            UpdateStatus();
            HighlightActiveButton(button1);
            button1.PerformClick();
        }

        private void button8_Click(object sender, EventArgs e) // Выход
        {
            Form1 loginForm = new Form1();
            loginForm.Show();
            this.Close();
        }

        private void HighlightActiveButton(Button active)
        {
            Button[] buttons = { button1, button2, button3 };
            foreach (var btn in buttons)
            {
                if (btn == active)
                {
                    btn.BackColor = Color.FromArgb(52, 152, 219);
                    btn.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
                }
                else
                {
                    btn.BackColor = Color.FromArgb(149, 165, 166);
                    btn.Font = new Font("Segoe UI", 12F, FontStyle.Regular);
                }
            }
        }
        private void button9_Click(object sender, EventArgs e)
        {
            string aboutText =
                "═══════════════════════════════════════════════\n" +
                "      ПРОГРАММА УЧЁТА ОБОРУДОВАНИЯ\n" +
                "═══════════════════════════════════════════════\n\n" +
                "Организация: Завод \"Залив им. Б.Е. Бутомы\"\n" +
                "Разработчик: Магла Георгий Валерьевич\n" +
                "Версия: 1.0\n\n" +
                "═══════════════════════════════════════════════\n" +
                "           РУКОВОДСТВО ПОЛЬЗОВАТЕЛЯ\n" +
                "═══════════════════════════════════════════════\n\n" +
                "1. ГЛАВНОЕ ОКНО\n" +
                "   - Таблица со всем оборудованием.\n" +
                "   - Поиск: введите текст в поле \"Поиск\" – фильтрация по категории, названию, модели.\n" +
                "   - Сортировка: выберите параметр в списке \"Сортировать по\".\n" +
                "   - Строка состояния показывает количество записей.\n\n" +
                "2. БОКОВОЕ МЕНЮ\n" +
                "   • На складе – показать всё оборудование.\n" +
                "   • Привозы – фильтр по дате поставки.\n" +
                "   • Выдача сотруднику – управление сотрудниками и выдача/возврат.\n" +
                "   • Добавить – новое оборудование (категория, название, модель, количество, дата привоза).\n" +
                "   • Редактировать – изменить выбранную запись.\n" +
                "   • Удалить – удалить выбранное оборудование (связанные выдачи удаляются).\n" +
                "   • Сброс фильтров – очищает поиск и сортировку.\n" +
                "   • Выход – закрыть программу.\n\n" +
                "3. ФОРМА \"ВЫДАЧА СОТРУДНИКУ\"\n" +
                "   - Слева список сотрудников, кнопка \"Добавить сотрудника\".\n" +
                "   - Вверху справа – оборудование, выданное выбранному сотруднику.\n" +
                "   - Внизу справа – доступное оборудование на складе.\n" +
                "   - Кнопка \"Выдать\" – переносит выбранное оборудование сотруднику.\n" +
                "   - Кнопка \"Забрать\" – возврат оборудования на склад.\n\n" +
                "4. ФОРМА ДОБАВЛЕНИЯ/РЕДАКТИРОВАНИЯ\n" +
                "   - Выберите категорию из списка.\n" +
                "   - Введите название, модель (необязательно), количество, дату привоза.\n" +
                "   - При редактировании изменение общего количества корректирует свободные единицы.\n\n" +
                "5. СТАТУСЫ ОБОРУДОВАНИЯ\n" +
                "   - На складе (зелёный) – всё оборудование свободно.\n" +
                "   - Распределено (жёлтый) – часть выдана, часть на складе.\n" +
                "   - Выдано (красный) – всё оборудование выдано.\n\n";

            MessageBox.Show(aboutText, "О программе и руководство пользователя",
                            MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}