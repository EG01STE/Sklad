﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Sklad
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            ApplyRoundedButtons();
        }

        private void ApplyRoundedButtons()
        {
            MakeButtonRounded(button1);
            MakeButtonRounded(button2);
        }

        private void MakeButtonRounded(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            int radius = 8;
            path.AddArc(0, 0, radius, radius, 180, 90);
            path.AddArc(btn.Width - radius, 0, radius, radius, 270, 90);
            path.AddArc(btn.Width - radius, btn.Height - radius, radius, radius, 0, 90);
            path.AddArc(0, btn.Height - radius, radius, radius, 90, 90);
            path.CloseFigure();
            btn.Region = new Region(path);
        }

        // Эффекты наведения
        private void Button_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn == button1)
                btn.BackColor = Color.FromArgb(41, 128, 185);
            else if (btn == button2)
                btn.BackColor = Color.FromArgb(127, 140, 141);
        }

        private void Button_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn == button1)
                btn.BackColor = Color.FromArgb(52, 152, 219);
            else if (btn == button2)
                btn.BackColor = Color.FromArgb(149, 165, 166);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = !checkBox1.Checked;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = textBox1.Text.Trim();
            string password = textBox2.Text;

            DataTable dt = DatabaseHelper.ExecuteQuery(
                "SELECT COUNT(*) AS Valid FROM Users WHERE Login = @login AND PasswordHash = @pwd",
                new SqlParameter[] { new SqlParameter("@login", login), new SqlParameter("@pwd", password) });

            if (dt.Rows.Count > 0 && Convert.ToInt32(dt.Rows[0]["Valid"]) > 0)
            {
                Form2 mainForm = new Form2();
                mainForm.Show();
                this.Hide();
            }
            else
            {
                label3.Text = "Неверный логин или пароль!";
                label3.Visible = true;
            }
        }
    }
}