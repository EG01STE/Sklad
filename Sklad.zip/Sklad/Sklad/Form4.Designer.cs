﻿namespace Sklad
{
    partial class Form4
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ComboBox comboBoxCategory;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxModel;
        private System.Windows.Forms.NumericUpDown numericTotal;
        private System.Windows.Forms.DateTimePicker dateTimeDelivery;
        private System.Windows.Forms.Button buttonSave;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelTitle;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.comboBoxCategory = new System.Windows.Forms.ComboBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxModel = new System.Windows.Forms.TextBox();
            this.numericTotal = new System.Windows.Forms.NumericUpDown();
            this.dateTimeDelivery = new System.Windows.Forms.DateTimePicker();
            this.buttonSave = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericTotal)).BeginInit();
            this.SuspendLayout();

            // Form4
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.ClientSize = new System.Drawing.Size(450, 420);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Оборудование";
            this.Font = new System.Drawing.Font("Segoe UI", 10F);

            // labelTitle
            this.labelTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.labelTitle.ForeColor = System.Drawing.Color.FromArgb(44, 62, 80);
            this.labelTitle.Location = new System.Drawing.Point(20, 20);
            this.labelTitle.Name = "labelTitle";
            this.labelTitle.Size = new System.Drawing.Size(410, 35);
            this.labelTitle.Text = "Добавление оборудования";
            this.labelTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;

            // label1 (Категория)
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.label1.Location = new System.Drawing.Point(40, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 19);
            this.label1.Text = "Категория:";

            // comboBoxCategory
            this.comboBoxCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCategory.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.comboBoxCategory.Location = new System.Drawing.Point(160, 77);
            this.comboBoxCategory.Name = "comboBoxCategory";
            this.comboBoxCategory.Size = new System.Drawing.Size(240, 28);
            this.comboBoxCategory.TabIndex = 1;

            // label2 (Название)
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.label2.Location = new System.Drawing.Point(40, 130);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 19);
            this.label2.Text = "Название:";

            // textBoxName
            this.textBoxName.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.textBoxName.Location = new System.Drawing.Point(160, 127);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(240, 27);
            this.textBoxName.TabIndex = 2;

            // label3 (Модель)
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.label3.Location = new System.Drawing.Point(40, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 19);
            this.label3.Text = "Модель:";

            // textBoxModel
            this.textBoxModel.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.textBoxModel.Location = new System.Drawing.Point(160, 177);
            this.textBoxModel.Name = "textBoxModel";
            this.textBoxModel.Size = new System.Drawing.Size(240, 27);
            this.textBoxModel.TabIndex = 3;

            // label4 (Количество)
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.label4.Location = new System.Drawing.Point(40, 230);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 19);
            this.label4.Text = "Количество:";

            // numericTotal
            this.numericTotal.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.numericTotal.Location = new System.Drawing.Point(160, 227);
            this.numericTotal.Minimum = 1;
            this.numericTotal.Name = "numericTotal";
            this.numericTotal.Size = new System.Drawing.Size(120, 27);
            this.numericTotal.TabIndex = 4;
            this.numericTotal.Value = 1;

            // label5 (Дата привоза)
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.FromArgb(52, 73, 94);
            this.label5.Location = new System.Drawing.Point(40, 280);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 19);
            this.label5.Text = "Дата привоза:";

            // dateTimeDelivery
            this.dateTimeDelivery.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.dateTimeDelivery.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimeDelivery.Location = new System.Drawing.Point(160, 277);
            this.dateTimeDelivery.Name = "dateTimeDelivery";
            this.dateTimeDelivery.Size = new System.Drawing.Size(160, 27);
            this.dateTimeDelivery.TabIndex = 5;

            // buttonSave
            this.buttonSave.BackColor = System.Drawing.Color.FromArgb(52, 152, 219);
            this.buttonSave.FlatAppearance.BorderSize = 0;
            this.buttonSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSave.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.buttonSave.ForeColor = System.Drawing.Color.White;
            this.buttonSave.Location = new System.Drawing.Point(100, 340);
            this.buttonSave.Name = "buttonSave";
            this.buttonSave.Size = new System.Drawing.Size(110, 35);
            this.buttonSave.TabIndex = 6;
            this.buttonSave.Text = "Сохранить";
            this.buttonSave.UseVisualStyleBackColor = false;
            this.buttonSave.Click += new System.EventHandler(this.buttonSave_Click);

            // buttonCancel
            this.buttonCancel.BackColor = System.Drawing.Color.FromArgb(149, 165, 166);
            this.buttonCancel.FlatAppearance.BorderSize = 0;
            this.buttonCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonCancel.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.buttonCancel.ForeColor = System.Drawing.Color.White;
            this.buttonCancel.Location = new System.Drawing.Point(240, 340);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(110, 35);
            this.buttonCancel.TabIndex = 7;
            this.buttonCancel.Text = "Отмена";
            this.buttonCancel.UseVisualStyleBackColor = false;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);

            // Добавляем элементы
            this.Controls.Add(this.labelTitle);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxCategory);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxModel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.numericTotal);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dateTimeDelivery);
            this.Controls.Add(this.buttonSave);
            this.Controls.Add(this.buttonCancel);

            ((System.ComponentModel.ISupportInitialize)(this.numericTotal)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}