﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Sklad
{
    public partial class Form4 : Form
    {
        private bool isEditMode = false;
        private int equipmentId = 0;
        private Form2 parentForm;

        public Form4(Form2 parent, int? editId = null)
        {
            InitializeComponent();
            parentForm = parent;
            LoadCategories();

            if (editId.HasValue && editId.Value > 0)
            {
                isEditMode = true;
                equipmentId = editId.Value;
                labelTitle.Text = "Редактирование оборудования";
                LoadEquipmentData(equipmentId);
            }
            else
            {
                labelTitle.Text = "Добавление оборудования";
                dateTimeDelivery.Value = DateTime.Now;
            }
        }

        private void LoadCategories()
        {
            DataTable dt = DatabaseHelper.ExecuteQuery("SELECT CategoryID, CategoryName FROM Categories ORDER BY CategoryName");
            comboBoxCategory.DisplayMember = "CategoryName";
            comboBoxCategory.ValueMember = "CategoryID";
            comboBoxCategory.DataSource = dt;
        }

        private void LoadEquipmentData(int id)
        {
            DataTable dt = DatabaseHelper.ExecuteQuery("SELECT * FROM Equipment WHERE EquipmentID = @id",
                new SqlParameter[] { new SqlParameter("@id", id) });
            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                comboBoxCategory.SelectedValue = row["CategoryID"];
                textBoxName.Text = row["Name"].ToString();
                textBoxModel.Text = row["Model"] == DBNull.Value ? "" : row["Model"].ToString();
                numericTotal.Value = Convert.ToDecimal(row["TotalQuantity"]);

                int deliveryId = Convert.ToInt32(row["DeliveryID"]);
                LoadDeliveryDate(deliveryId);
            }
        }

        private void LoadDeliveryDate(int deliveryId)
        {
            DataTable dt = DatabaseHelper.ExecuteQuery("SELECT DeliveryDate FROM Deliveries WHERE DeliveryID = @id",
                new SqlParameter[] { new SqlParameter("@id", deliveryId) });
            if (dt.Rows.Count > 0)
                dateTimeDelivery.Value = Convert.ToDateTime(dt.Rows[0]["DeliveryDate"]);
        }

        private int GetOrCreateDeliveryId(DateTime deliveryDate)
        {
            // Проверяем, есть ли уже поставка с такой датой
            DataTable dt = DatabaseHelper.ExecuteQuery("SELECT DeliveryID FROM Deliveries WHERE DeliveryDate = @date",
                new SqlParameter[] { new SqlParameter("@date", deliveryDate) });
            if (dt.Rows.Count > 0)
            {
                return Convert.ToInt32(dt.Rows[0]["DeliveryID"]);
            }
            else
            {
                // Создаём новую поставку
                DatabaseHelper.ExecuteNonQuery("INSERT INTO Deliveries (DeliveryDate) VALUES (@date)",
                    new SqlParameter[] { new SqlParameter("@date", deliveryDate) });
                // Получаем новый ID через SCOPE_IDENTITY()
                object result = DatabaseHelper.ExecuteScalar("SELECT SCOPE_IDENTITY()");
                if (result == null || result == DBNull.Value)
                    throw new Exception("Не удалось получить идентификатор новой поставки.");
                return Convert.ToInt32(result);
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            // Проверка заполнения
            if (comboBoxCategory.SelectedValue == null)
            {
                MessageBox.Show("Выберите категорию.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (string.IsNullOrWhiteSpace(textBoxName.Text))
            {
                MessageBox.Show("Введите название оборудования.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int categoryId = (int)comboBoxCategory.SelectedValue;
            string name = textBoxName.Text.Trim();
            string model = textBoxModel.Text.Trim();
            int total = (int)numericTotal.Value;
            DateTime deliveryDate = dateTimeDelivery.Value.Date;

            try
            {
                int deliveryId = GetOrCreateDeliveryId(deliveryDate);

                if (isEditMode)
                {
                    // Обновляем существующую запись
                    string query = @"
                        UPDATE Equipment 
                        SET CategoryID = @cat, Name = @name, Model = @model, 
                            TotalQuantity = @total, DeliveryID = @deliveryId
                        WHERE EquipmentID = @id";
                    DatabaseHelper.ExecuteNonQuery(query,
                        new SqlParameter[] {
                            new SqlParameter("@cat", categoryId),
                            new SqlParameter("@name", name),
                            new SqlParameter("@model", model),
                            new SqlParameter("@total", total),
                            new SqlParameter("@deliveryId", deliveryId),
                            new SqlParameter("@id", equipmentId)
                        });
                    // Пересчитываем Available, чтобы Issued не изменился
                    DataTable dtIssued = DatabaseHelper.ExecuteQuery("SELECT Issued FROM Equipment WHERE EquipmentID = @id",
                        new SqlParameter[] { new SqlParameter("@id", equipmentId) });
                    if (dtIssued.Rows.Count > 0)
                    {
                        int issued = Convert.ToInt32(dtIssued.Rows[0]["Issued"]);
                        int newAvailable = total - issued;
                        if (newAvailable < 0) newAvailable = 0;
                        DatabaseHelper.ExecuteNonQuery("UPDATE Equipment SET Available = @av WHERE EquipmentID = @id",
                            new SqlParameter[] { new SqlParameter("@av", newAvailable), new SqlParameter("@id", equipmentId) });
                    }
                }
                else
                {
                    // Добавление нового оборудования (Available = TotalQuantity, Issued = 0)
                    string query = @"
                        INSERT INTO Equipment (CategoryID, Name, Model, TotalQuantity, Available, Issued, DeliveryID)
                        VALUES (@cat, @name, @model, @total, @total, 0, @deliveryId)";
                    DatabaseHelper.ExecuteNonQuery(query,
                        new SqlParameter[] {
                            new SqlParameter("@cat", categoryId),
                            new SqlParameter("@name", name),
                            new SqlParameter("@model", model),
                            new SqlParameter("@total", total),
                            new SqlParameter("@deliveryId", deliveryId)
                        });
                }

                MessageBox.Show("Данные сохранены.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                parentForm.RefreshEquipmentData();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при сохранении: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}