﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace Sklad
{
    public partial class Form3 : Form
    {
        private Form2 mainForm;
        private int selectedEmployeeId = -1;

        public Form3(Form2 form2)
        {
            InitializeComponent();
            mainForm = form2;
            ApplyButtonsRounded();
            LoadEmployees();
            LoadAvailableEquipment();
        }

        private void ApplyButtonsRounded()
        {
            MakeButtonRounded(button1);
            MakeButtonRounded(button2);
            MakeButtonRounded(button3);
            MakeButtonRounded(button4);
        }

        private void MakeButtonRounded(Button btn)
        {
            btn.FlatStyle = FlatStyle.Flat;
            btn.FlatAppearance.BorderSize = 0;
            System.Drawing.Drawing2D.GraphicsPath path = new System.Drawing.Drawing2D.GraphicsPath();
            int radius = 8;
            path.AddArc(0, 0, radius, radius, 180, 90);
            path.AddArc(btn.Width - radius, 0, radius, radius, 270, 90);
            path.AddArc(btn.Width - radius, btn.Height - radius, radius, radius, 0, 90);
            path.AddArc(0, btn.Height - radius, radius, radius, 90, 90);
            path.CloseFigure();
            btn.Region = new Region(path);
        }

        private void LoadEmployees()
        {
            DataTable dt = DatabaseHelper.ExecuteQuery("SELECT EmployeeID, EmployeeName FROM Employees ORDER BY EmployeeName");
            listBox1.DataSource = dt;
            listBox1.DisplayMember = "EmployeeName";
            listBox1.ValueMember = "EmployeeID";
        }

        private void LoadAvailableEquipment()
        {
            DataTable dt = DatabaseHelper.ExecuteQuery(
                "SELECT EquipmentID, Name + ' ' + ISNULL(Model, '') AS FullName, Available " +
                "FROM Equipment WHERE Available > 0 ORDER BY Name");
            dataGridView2.DataSource = dt;
            if (dataGridView2.Columns["EquipmentID"] != null)
                dataGridView2.Columns["EquipmentID"].Visible = false;
            dataGridView2.Columns["FullName"].HeaderText = "Оборудование";
            dataGridView2.Columns["Available"].HeaderText = "Свободно";
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void LoadEmployeeIssues(int employeeId)
        {
            DataTable dt = DatabaseHelper.ExecuteQuery(
                @"SELECT i.IssueID, e.Name + ' ' + ISNULL(e.Model, '') AS EquipmentName, i.IssueDate
          FROM Issues i
          INNER JOIN Equipment e ON i.EquipmentID = e.EquipmentID
          WHERE i.EmployeeID = @empId AND i.ReturnDate IS NULL",
                new SqlParameter[] { new SqlParameter("@empId", employeeId) });
            dataGridView1.DataSource = dt;
            // Скрываем колонку IssueID (не переименовываем)
            if (dataGridView1.Columns["IssueID"] != null)
                dataGridView1.Columns["IssueID"].Visible = false;
            if (dataGridView1.Columns["EquipmentName"] != null)
                dataGridView1.Columns["EquipmentName"].HeaderText = "Оборудование";
            if (dataGridView1.Columns["IssueDate"] != null)
            {
                dataGridView1.Columns["IssueDate"].HeaderText = "Дата выдачи";
                dataGridView1.Columns["IssueDate"].DefaultCellStyle.Format = "dd.MM.yyyy";
            }
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedValue != null && int.TryParse(listBox1.SelectedValue.ToString(), out int empId))
            {
                selectedEmployeeId = empId;
                LoadEmployeeIssues(empId);
            }
        }

        private void button3_Click(object sender, EventArgs e) // Добавить сотрудника
        {
            string name = ShowInputDialog("Введите имя сотрудника:", "Новый сотрудник");
            if (!string.IsNullOrWhiteSpace(name))
            {
                DatabaseHelper.ExecuteNonQuery("INSERT INTO Employees (EmployeeName) VALUES (@name)",
                    new SqlParameter[] { new SqlParameter("@name", name) });
                LoadEmployees();
            }
        }

        private void button2_Click(object sender, EventArgs e) // Выдать оборудование (раньше был button1, проверьте)
        {
            if (selectedEmployeeId == -1)
            {
                MessageBox.Show("Выберите сотрудника.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dataGridView2.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите оборудование для выдачи.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            int equipId = (int)dataGridView2.SelectedRows[0].Cells["EquipmentID"].Value;
            try
            {
                DatabaseHelper.GiveEquipment(selectedEmployeeId, equipId);
                LoadAvailableEquipment();
                LoadEmployeeIssues(selectedEmployeeId);
                mainForm.RefreshEquipmentData();
                MessageBox.Show("Оборудование выдано.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при выдаче: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e) // Забрать оборудование
        {
            if (selectedEmployeeId == -1)
            {
                MessageBox.Show("Выберите сотрудника.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите оборудование для возврата.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // Теперь столбец называется IssueID (хотя он скрыт, значение доступно)
            int issueId = (int)dataGridView1.SelectedRows[0].Cells["IssueID"].Value;
            try
            {
                DatabaseHelper.ReturnEquipment(issueId);
                LoadAvailableEquipment();
                LoadEmployeeIssues(selectedEmployeeId);
                mainForm.RefreshEquipmentData();
                MessageBox.Show("Оборудование возвращено.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при возврате: " + ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private string ShowInputDialog(string prompt, string title)
        {
            Form dialog = new Form();
            dialog.Text = title;
            dialog.Width = 350;
            dialog.Height = 150;
            dialog.FormBorderStyle = FormBorderStyle.FixedDialog;
            dialog.MaximizeBox = false;
            dialog.MinimizeBox = false;
            dialog.StartPosition = FormStartPosition.CenterParent;
            dialog.BackColor = Color.White;

            Label label = new Label() { Text = prompt, Left = 20, Top = 20, Width = 280, Font = new Font("Segoe UI", 10F) };
            TextBox textBox = new TextBox() { Left = 20, Top = 50, Width = 250, Font = new Font("Segoe UI", 10F) };
            Button okButton = new Button()
            {
                Text = "OK",
                Left = 100,
                Width = 70,
                Top = 85,
                DialogResult = DialogResult.OK,
                BackColor = Color.FromArgb(52, 152, 219),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            Button cancelButton = new Button()
            {
                Text = "Отмена",
                Left = 180,
                Width = 70,
                Top = 85,
                DialogResult = DialogResult.Cancel,
                BackColor = Color.FromArgb(149, 165, 166),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };

            dialog.Controls.Add(label);
            dialog.Controls.Add(textBox);
            dialog.Controls.Add(okButton);
            dialog.Controls.Add(cancelButton);
            dialog.AcceptButton = okButton;
            dialog.CancelButton = cancelButton;

            if (dialog.ShowDialog() == DialogResult.OK)
                return textBox.Text;
            return "";
        }
    }
}